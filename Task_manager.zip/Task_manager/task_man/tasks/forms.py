from django import forms
from .models import Task
from users.models import User

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'assigned_to', 'status']

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)  # receive current logged-in user
        super().__init__(*args, **kwargs)

        if user:
            if user.role == 'manager':
                # Managers can assign tasks only to their employees
                self.fields['assigned_to'].queryset = User.objects.filter(manager=user, role='employee')
            elif user.role == 'employee':
                # Employees can only be assigned tasks to themselves
                self.fields['assigned_to'].queryset = User.objects.filter(pk=user.pk)
                self.fields['assigned_to'].disabled = True  # employees can't reassign tasks
            elif user.role == 'admin':
                # Admins can assign tasks to anyone
                self.fields['assigned_to'].queryset = User.objects.all()
            else:
                self.fields['assigned_to'].queryset = User.objects.none()
        else:
            self.fields['assigned_to'].queryset = User.objects.none()

        # Employees can only update status in update forms; disable other fields
        if user and user.role == 'employee' and self.instance.pk:
            self.fields['title'].disabled = True
            self.fields['description'].disabled = True
            self.fields['assigned_to'].disabled = True
