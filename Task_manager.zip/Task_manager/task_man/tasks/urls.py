from django.urls import path
from .views import task_list, task_create,task_update, task_delete,user_list,user_task_list

urlpatterns = [
    path('', task_list, name='task-list'),
    path('create/', task_create, name='task-create'),
    path('<int:pk>/update/', task_update, name='task-update'),
    path('<int:pk>/delete/', task_delete, name='task-delete'),
     path('users/', user_list, name='user-list'),             
    path('users/<int:user_id>/tasks/', user_task_list, name='user-task-list'), 
]
