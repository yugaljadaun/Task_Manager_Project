from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Task
from users.models import User
from .forms import TaskForm

@login_required
def task_list(request):
    user = request.user
    if user.role == 'admin':
        tasks = Task.objects.all()
    elif user.role == 'manager':
        # Managers see tasks assigned to their employees only
        tasks = Task.objects.filter(assigned_to__manager=user)
    else:  # employee
        tasks = Task.objects.filter(assigned_to=user)
    return render(request, 'tasks/task_list.html', {'tasks': tasks})

@login_required
def user_list(request):
    if request.user.role == 'admin':
        users = User.objects.all()
    elif request.user.role == 'manager':
        users = request.user.employees.all()  # employees under this manager
    else:
        return redirect('task-list')  # employees don’t manage users
    return render(request, 'tasks/user_list.html', {'users': users})

@login_required
def user_task_list(request, user_id):
    user = get_object_or_404(User, pk=user_id)

    # Access control
    if request.user.role == 'manager' and user.manager != request.user:
        return redirect('user-list')
    elif request.user.role == 'employee' and user != request.user:
        return redirect('task-list')

    tasks = Task.objects.filter(assigned_to=user)
    return render(request, 'tasks/task_list.html', {'tasks': tasks, 'viewing_user': user})

@login_required
def task_create(request):
    if request.method == 'POST':
        form = TaskForm(request.POST, user=request.user)
        if form.is_valid():
            form.save()
            return redirect('task-list')
    else:
        form = TaskForm(user=request.user)
    return render(request, 'tasks/task_form.html', {'form': form})

@login_required
def task_update(request, pk):
    task = get_object_or_404(Task, pk=pk)

    # Role-based access control: 
    user = request.user
    if user.role == 'employee' and task.assigned_to != user:
        messages.error(request, "You don't have permission to edit this task.")
        return redirect('task-list')
    if user.role == 'manager' and task.assigned_to.role != 'employee':
        messages.error(request, "Managers can only edit tasks assigned to employees.")
        return redirect('task-list')

    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task, user=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Task updated successfully.")
            return redirect('task-list')
    else:
        form = TaskForm(instance=task, user=request.user)

    return render(request, 'tasks/task_form.html', {'form': form, 'is_update': True})

@login_required
def task_delete(request, pk):
    task = get_object_or_404(Task, pk=pk)

    user = request.user
    if user.role == 'employee' and task.assigned_to != user:
        messages.error(request, "You don't have permission to delete this task.")
        return redirect('task-list')
    if user.role == 'manager' and task.assigned_to.role != 'employee':
        messages.error(request, "Managers can only delete tasks assigned to employees.")
        return redirect('task-list')

    if request.method == 'POST':
        task.delete()
        messages.success(request, "Task deleted successfully.")
        return redirect('task-list')

    return render(request, 'tasks/task_confirm_delete.html', {'task': task})
