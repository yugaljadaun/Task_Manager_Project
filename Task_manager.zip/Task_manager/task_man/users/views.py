from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth import login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .forms import CustomUserCreationForm, CustomAuthenticationForm
from django.contrib.auth import login as auth_login

def login_view(request):
    if request.method == 'POST':
        form = CustomAuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            return redirect('home')
    else:
        form = CustomAuthenticationForm()
    return render(request, 'users/login.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'users/register.html', {'form': form})

def logout_view(request):
    auth_logout(request)
    return redirect('login')


@login_required
def home(request):
    user = request.user
    if user.role == 'admin':
        return HttpResponse("Admin Dashboard - Manage users and tasks")
    elif user.role == 'manager':
        return HttpResponse("Manager Dashboard - Create and assign tasks")
    elif user.role == 'employee':
        return HttpResponse("Employee Dashboard - View your tasks")
    else:
        return HttpResponse("No role assigned")
